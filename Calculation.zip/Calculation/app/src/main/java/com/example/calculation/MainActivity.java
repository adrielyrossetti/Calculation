package com.example.calculation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String Valor1 = "Digite o primeiro valor";
        String Valor2 = "Digite o segundo valor";
        String Valor3 = "Digite o Terceiro valor";

        TextView txtMensagem1 = findViewById(R.id.txtMensagem1);
        TextView txtMensagem2 = findViewById(R.id.textMensagem2);
        TextView txtMensagem3 = findViewById(R.id.txtMensagem3);
        //vai procurar dentro da view pelo id

        //coloca os textos na tela
        txtMensagem1.setText(Valor1);
        txtMensagem2.setText(Valor2);
        txtMensagem3.setText(Valor3);

        // instancia o botao com a interface
        Button buttonSomar = findViewById(R.id.buttonSomar);
        // habilita a funcao de clique junto a interfade
        buttonSomar.setOnClickListener(new View.OnClickListener() {

            // metodo do clique
            @Override
            public void onClick(View view) {
                // funcionalidade do clique no botao
                EditText uno = findViewById(R.id.caixaum);
                EditText dos = findViewById(R.id.caixadois );
                EditText tres = findViewById(R.id.caixatres);

                String numero1 = uno.getText().toString();
                int n1 = Integer.parseInt(numero1);
                String numero2 = dos.getText().toString();
                int n2 = Integer.parseInt(numero2);
                String numero3 = tres.getText().toString();
                int n3 = Integer.parseInt(numero3);

                TextView txtresultado = findViewById(R.id.result);
                //int resultad = Integer.parseInt();
                int resultad = n1+n2+n3;

                String resultfinal = String.valueOf(resultad);
                txtresultado.setText(resultfinal);

            }
        });
    }
}